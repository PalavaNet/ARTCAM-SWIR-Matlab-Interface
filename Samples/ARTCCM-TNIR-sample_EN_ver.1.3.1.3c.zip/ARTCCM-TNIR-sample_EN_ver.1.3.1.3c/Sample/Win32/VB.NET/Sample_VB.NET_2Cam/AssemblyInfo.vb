Imports System.Reflection
Imports System.Runtime.InteropServices

' General information for assembly are controlled by following set of attribute value.
' To change information related to assembly, modify those attribute values.
' Change these attribute value 

' Confirm value of assembly attribute

<Assembly: AssemblyTitle("")> 
<Assembly: AssemblyDescription("")> 
<Assembly: AssemblyCompany("")> 
<Assembly: AssemblyProduct("")> 
<Assembly: AssemblyCopyright("")> 
<Assembly: AssemblyTrademark("")> 
<Assembly: CLSCompliant(True)> 

'When this project is released in COM, following GUID will become ID of type library.
<Assembly: Guid("AB092D20-26AF-495C-85E2-CEFA7C89C333")> 

' Version information of assembly consists of following 4 attribute values: :
'
'      Major version
'      Minor version 
'      Build number
'      Revision
'
' You can set values using '*' as below.
' You can set "Build" and "Revision number" as set value.:

<Assembly: AssemblyVersion("1.0.*")> 
